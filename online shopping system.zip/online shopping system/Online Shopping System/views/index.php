<?php
include '../controllers/LoggedCheck.php';
if (loggedCheck()) {
    header('Location: ./profile.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Shopping System</title>
</head>

<body>
    <h1>Welcome to Online Shopping System</h1>
    <hr>
    <a href="./registration.php">Registration</a>
    <a href="./login.php">Login</a>
    <?php
    require './footer.php';
    ?>
</body>

</html>