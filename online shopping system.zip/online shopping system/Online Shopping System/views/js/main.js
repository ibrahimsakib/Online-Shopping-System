function registrationValidation() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var password = document.getElementById("password").value;
    var address = document.getElementById("address").value;

    if (name == "") {
        alert("Name is required");
        return false;
    }
    if (email == "") {
        alert("Email is required");
        return false;
    }
    if (phone == "") {
        alert("Phone is required");
        return false;
    }
    if (password == "" || password.length < 8) {
        alert("Password is required and must be at least 8 characters");
        return false;
    }
    if (address == "") {
        alert("Address is required");
        return false;
    }
    return true;
}

function loginValidation() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    if (email == "") {
        alert("Email is required");
        return false;
    }
    if (password == "" || password.length < 8) {
        alert("Password is required");
        return false;
    }
    return true;
}

