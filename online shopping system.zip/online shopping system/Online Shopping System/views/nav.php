<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Online Shopping System</title>
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <nav>
        <a href="./profile.php">Profile</a>
        <a href="./products.php">Product Manager</a>
       
        <a href="../controllers/logout.php">Logout</a>
    </nav>
</body>

</html>